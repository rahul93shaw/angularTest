import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from 'src/app/users/model/user.model';
import { throwError } from 'rxjs/internal/observable/throwError';
import { Observable } from 'rxjs';

@Injectable()
export class UserService {
  apiUrl = 'http://localhost:8080/service/users/';
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  constructor(private http: HttpClient) {}

  getUsers(): Observable<User[]> {
    return this.http.get(`${this.apiUrl}` + `getUsers`)
    .pipe(this.errorHandler);
  }

  getUser(userid: any): Observable<User> {
    return this.http.get(`${this.apiUrl}` + `getUser/` + `${userid}`)
    .pipe(this.errorHandler); 
  }

  createUser(user: User): Observable<User>{
    return this.http.post(`${this.apiUrl}` + `createUser`, user)
    .pipe(this.errorHandler);
  }

  deleteUser(userId: string): Observable<string>{
    return this.http.post(`${this.apiUrl}` + `deleteUser/`, userId)
    .pipe(this.errorHandler);
  }

  updateUser(userId: string): Observable<User>{
    return this.http.put(`${this.apiUrl}` + `updateUser/`, userId)
    .pipe(this.errorHandler);
  }

  errorHandler(error) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
 }
}