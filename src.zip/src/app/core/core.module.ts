import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { UserService } from './services/user.service';
import { PageHeaderComponent } from './components/page-header/page-header.component';
import { PageFooterComponent } from './components/page-footer/page-footer.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule
  ],
  providers: [
    UserService
  ],
  declarations: [
    PageHeaderComponent,
    PageFooterComponent
  ],
  exports: [
    PageHeaderComponent,
    PageFooterComponent
  ],
})
export class CoreModule { }