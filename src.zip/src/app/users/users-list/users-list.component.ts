import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/core/services/user.service';
import { User } from '../model/user.model';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.scss']
})
export class UsersListComponent implements OnInit {
  user: User;
  userList: User[];

  constructor(private userService: UserService) {}

  ngOnInit() {
    debugger;
    this.userService.getUsers().subscribe(result => {
      this.userList = result;
    });
  }

  getDetail($event, userId) {
    this.userService.updateUser(userId).subscribe(result => {
      this.user = result;
    });
  }
}