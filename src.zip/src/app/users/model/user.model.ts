export class User {
    userId: string;
    username: string;
    fullname: string;
    init() {
        this.userId = '';
        this.username = '';
        this.fullname = '';
        
    }
    constructor() {
        this.init();
    }
}
